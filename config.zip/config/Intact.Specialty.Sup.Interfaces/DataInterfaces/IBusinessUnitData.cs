﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Interfaces.DataInterfaces
{
    public interface IBusinessUnitData
    {
        void MapMyData();
    }
}
