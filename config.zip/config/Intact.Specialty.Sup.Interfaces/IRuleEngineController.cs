﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Interfaces
{
    public interface IRuleEngineController
    {
        string Check();
    }
}
