﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Interfaces.ServiceInterfaces
{
    public interface IPolicyAdminService
    {
        string Check();
    }
}
