﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Interfaces.ServiceInterfaces
{
    public interface IBusinessUnitService
    {
        List<string> GetBusinessUnits();
        string GetGeography();
        List<string> AppendPrefixtoMyBU();
        string SpecificCode();
        string ThisOnlyForUS();
    }
}
