﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Interfaces
{
    public interface IDataController
    {
        object OpenDataStore();
    }
}
