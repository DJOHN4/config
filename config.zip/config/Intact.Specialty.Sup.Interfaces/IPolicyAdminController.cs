﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Interfaces
{
    public interface IPolicyAdminController
    {
        string Check();
    }
}
