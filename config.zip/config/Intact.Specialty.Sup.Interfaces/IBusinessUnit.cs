﻿using System;
using System.Collections.Generic;

namespace Intact.Specialty.Sup.Interfaces
{
    public interface IBusinessUnit
    {
        List<string> GetAllMyBusinessUnits();
        string GetGeography();
        List<string> AppendPrefixtoMyBU();
        string SpecificCode();
        string ThisOnlyForUS();
    }
}
