using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}

/*
 * 
 * ,
    {
      "Country": "Canada",
      "Region": "CANADA",
      "Elements": {
        "BusinessUnits": [
          "BU-1",
          "BU-2",
          "BU-3",
          "BU-4"
        ],
        "Producers": [
          "CA-PR-1",
          "CA-PR-2",
          "CA-PR-3",
          "CA-PR-4"
        ],
        "PolicyContact": [
          "CA-PC-1",
          "CA-PC-2",
          "CA-PC-3",
          "CA-PC-4"
        ],
        "Teritories": [
          "CA-TR-1",
          "CA-TR-2",
          "CA-TR-3",
          "CA-TR-4"
        ],
        "ProgramTypes": [
          "CA-PT-1",
          "CA-PT-2",
          "CA-PT-3",
          "CA-PT-4"
        ],
        "UWCompany": [
          "ASIC",
          "OBIN",
          "OBAIC"
        ],
        "OperatingCompany": [
          "IMU",
          "IM",
          "SP",
          "ENT",
          "AH"
        ],
        "States": [
          "NY",
          "CT",
          "NJ",
          "PA"
        ],
        "Products": [
          "AUTO",
          "GL",
          "Property"
        ],
        "TransactionTypes": [
          "NEW",
          "REN",
          "EDR",
          "CAN",
          "REIN"
        ],
        "Coverage": [
          "COV-1",
          "COV-2"
        ]
      }
    }
*/