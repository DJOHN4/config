﻿using Intact.Specialty.Sup.Framework;
using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.DataInterfaces;
using Intact.Specialty.Sup.Interfaces.ServiceInterfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Services
{
    public class BusinessUnitService : IBusinessUnitService
    {
        private IDataController dataController = null;
        private string dataControllerType = string.Empty;
        IBusinessUnitData busUnitData = null; //This is based on need ***
        private string platformRegion = string.Empty;

        public BusinessUnitService(IBusinessUnitData buData, IConfiguration configuration)
        {
            busUnitData = buData;
            dataControllerType = configuration.GetValue<string>("DataControllerType");
            platformRegion = configuration.GetValue<string>("PlatformRegion");
        }

        public List<string> AppendPrefixtoMyBU()
        {
            List<string> buList = null;

            BusinessUnitFactory buFactory = BusinessUnitFactory.GetBusinessUnitFactory(platformRegion);
            if (buFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                //TODO: Need to check - DataController is passing for even functions that do not need Data Controller
                //How to fix this?
                dataController = DataControllerFactory.GetDataControllerFactory(dataControllerType).GetDataController(); 
                IBusinessUnit busUnit = buFactory.GetBusinessUnits(platformRegion, dataController);
                buList = busUnit.AppendPrefixtoMyBU();
            }

            return buList;
        }

        public List<string> GetBusinessUnits()
        {
            List<string> buList = null;

            BusinessUnitFactory buFactory = BusinessUnitFactory.GetBusinessUnitFactory(platformRegion);
            if (buFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                dataController = DataControllerFactory.GetDataControllerFactory(dataControllerType).GetDataController();
                IBusinessUnit busUnit = buFactory.GetBusinessUnits(platformRegion, dataController);
                buList = busUnit.GetAllMyBusinessUnits();
            }

            return buList;
        }

        public string GetGeography()
        {
            string geography = string.Empty;
            BusinessUnitFactory buFactory = BusinessUnitFactory.GetBusinessUnitFactory(platformRegion);
            if (buFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                dataController = DataControllerFactory.GetDataControllerFactory(dataControllerType).GetDataController();
                IBusinessUnit busUnit = buFactory.GetBusinessUnits(platformRegion, dataController);
                geography = busUnit.GetGeography();
            }
            return geography;
        }

        public string SpecificCode()
        {
            string msg = string.Empty;
            BusinessUnitFactory buFactory = BusinessUnitFactory.GetBusinessUnitFactory(platformRegion);
            if (buFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                dataController = DataControllerFactory.GetDataControllerFactory(dataControllerType).GetDataController();
                IBusinessUnit busUnit = buFactory.GetBusinessUnits(platformRegion, dataController);
                msg = busUnit.SpecificCode();
            }
            return msg;
        }

        public string ThisOnlyForUS()
        {
            string msg = string.Empty;
            BusinessUnitFactory buFactory = BusinessUnitFactory.GetBusinessUnitFactory(platformRegion);
            if (buFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                dataController = DataControllerFactory.GetDataControllerFactory(dataControllerType).GetDataController();
                IBusinessUnit busUnit = buFactory.GetBusinessUnits(platformRegion, dataController);
                msg = busUnit.ThisOnlyForUS();
            }
            return msg;
        }
    }
}
