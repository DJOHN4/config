﻿using Intact.Specialty.Sup.Framework;
using Intact.Specialty.Sup.Framework.RE;
using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.ServiceInterfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Services
{
    public class RuleEngineService : IRuleEngineService
    {
        private string ruleEngineType = string.Empty;

        public RuleEngineService(IConfiguration configuration)
        {
           ruleEngineType = configuration.GetValue<string>("RuleEngine");
        }

        public string Check()
        {
            string msg = string.Empty;
            RuleEngineFactory reFactory = RuleEngineFactory.GetRuleEngineFactory(ruleEngineType);
            if (reFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                IRuleEngineController rEngine = reFactory.GetRuleEngineController();
                msg = rEngine.Check();
            }
            return msg;
        }
    }
}
