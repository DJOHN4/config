﻿using Intact.Specialty.Sup.Framework.RE;
using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.ServiceInterfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Services
{
    public class PolicyAdminService : IPolicyAdminService
    {
        private string ruleEngineType = string.Empty;

        public PolicyAdminService(IConfiguration configuration)
        {
            ruleEngineType = configuration.GetValue<string>("PolicyAdmin");
        }

        public string Check()
        {
            string msg = string.Empty;
            PolicyAdminFactory paFactory = PolicyAdminFactory.GetRuleEngineFactory(ruleEngineType);
            if (paFactory == null)
                Console.WriteLine("Platform not defined for this geography");
            else
            {
                IPolicyAdminController paEngine = paFactory.GetPolicyAdminController();
                msg = paEngine.Check();
            }
            return msg;
        }
    }
}
