﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Models
{
    public class PlatformResponse
    {
        public int ResponseCode { get; set; }
        public object ResponseData { get; set; }
        public ErrorData ErrorData { get; set; }
    }
    public class ErrorData
    {
        public int ErrorCode { get; set; }
        public string ErrorMsg { get; set; }
    }
}
