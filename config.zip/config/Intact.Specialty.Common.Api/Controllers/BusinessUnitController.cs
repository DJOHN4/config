﻿using Intact.Specialty.Common.Api.Models;
using Intact.Specialty.Sup.Interfaces.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BusinessUnitController : ControllerBase
    {
        private IBusinessUnitService busUnitService = null;

        public BusinessUnitController(IBusinessUnitService buService)
        {
            busUnitService = buService;
        }

        [HttpGet("/businessunits")]
        public PlatformResponse GetMyBusinessUnits()
        {
            string msg = string.Empty;
            PlatformResponse res = new PlatformResponse();
            try
            {
                res.ResponseData = busUnitService.GetBusinessUnits();
                if (res.ResponseData != null)
                    res.ResponseCode = Ok().StatusCode;
                else
                {
                    res.ResponseCode = StatusCode(500).StatusCode;
                    ErrorData err = new ErrorData();
                    err.ErrorCode = 322;
                    err.ErrorMsg = "Platform not defined for this geography";
                    res.ErrorData = err;
                }
            }
            catch (Exception xe)
            {
                res.ErrorData = new ErrorData();
                res.ErrorData.ErrorMsg = xe.Message;
                res.ErrorData.ErrorCode = 488;
            }

            return res;
        }
        [HttpGet("/region")]
        public PlatformResponse GetMyRegion()
        {
            string msg = string.Empty;
            PlatformResponse res = new PlatformResponse();
            try
            {
                res.ResponseData = busUnitService.GetGeography();
                if (!string.IsNullOrEmpty(res.ResponseData.ToString()))
                    res.ResponseCode = Ok().StatusCode;
                else
                {
                    res.ResponseCode = StatusCode(500).StatusCode;
                    ErrorData err = new ErrorData();
                    err.ErrorCode = 322;
                    err.ErrorMsg = "Platform not defined for this geography";
                    res.ErrorData = err;
                }
            }
            catch (Exception xe)
            {
                res.ErrorData = new ErrorData();
                res.ErrorData.ErrorMsg = xe.Message;
                res.ErrorData.ErrorCode = 488;
            }
            return res;
        }
        [HttpGet("/bu/prefix")]
        public PlatformResponse AppendPrefixtoMyBU()
        {
            string msg = string.Empty;
            PlatformResponse res = new PlatformResponse();
            try
            {
                res.ResponseData = busUnitService.AppendPrefixtoMyBU();
                if (res.ResponseData != null)
                    res.ResponseCode = Ok().StatusCode;
                else
                {
                    res.ResponseCode = StatusCode(500).StatusCode;
                    ErrorData err = new ErrorData();
                    err.ErrorCode = 322;
                    err.ErrorMsg = "Platform not defined for this geography";
                    res.ErrorData = err;
                }
            }
            catch (Exception xe)
            {
                res.ErrorData = new ErrorData();
                res.ErrorData.ErrorMsg = xe.Message;
                res.ErrorData.ErrorCode = 488;
            }
            return res;
        }
        [HttpGet("/bu/specific")]
        public PlatformResponse SpecificCode()
        {
            string msg = string.Empty;
            PlatformResponse res = new PlatformResponse();
            try
            {
                res.ResponseData = busUnitService.SpecificCode();
                if (!string.IsNullOrEmpty(res.ResponseData.ToString()))
                    res.ResponseCode = Ok().StatusCode;
                else
                {
                    res.ResponseCode = StatusCode(500).StatusCode;
                    ErrorData err = new ErrorData();
                    err.ErrorCode = 322;
                    err.ErrorMsg = "Platform not defined for this geography";
                    res.ErrorData = err;
                }
            }
            catch (Exception xe)
            {
                res.ErrorData = new ErrorData();
                res.ErrorData.ErrorMsg = xe.Message;
                res.ErrorData.ErrorCode = 488;
            }
            return res;
        }
        [HttpGet("/bu/forUS")]
        public PlatformResponse ThisOnlyForUS()
        {
            string msg = string.Empty;
            PlatformResponse res = new PlatformResponse();
            try
            {
                res.ResponseData = busUnitService.ThisOnlyForUS();
                if (!string.IsNullOrEmpty(res.ResponseData.ToString()))
                    res.ResponseCode = Ok().StatusCode;
                else
                {
                    res.ResponseCode = StatusCode(500).StatusCode;
                    ErrorData err = new ErrorData();
                    err.ErrorCode = 322;
                    err.ErrorMsg = "Platform not defined for this geography";
                    res.ErrorData = err;
                }
            }
            catch (Exception xe)
            {
                res.ErrorData = new ErrorData();
                res.ErrorData.ErrorMsg = xe.Message;
                res.ErrorData.ErrorCode = 488;
            }
            return res;
        }
    }
}
