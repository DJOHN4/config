﻿using Intact.Specialty.Common.Api.Models;
using Intact.Specialty.Sup.Interfaces.ServiceInterfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PolicyAdminController : ControllerBase
    {
        private IPolicyAdminService paService = null;

        public PolicyAdminController(IPolicyAdminService paSvc)
        {
            paService = paSvc;
        }

        [HttpGet("/check")]
        public PlatformResponse Check()
        {
            string msg = string.Empty;
            PlatformResponse res = new PlatformResponse();
            try
            {
                res.ResponseData = paService.Check();
                if (res.ResponseData != null)
                    res.ResponseCode = Ok().StatusCode;
                else
                {
                    res.ResponseCode = StatusCode(500).StatusCode;
                    ErrorData err = new ErrorData();
                    err.ErrorCode = 322;
                    err.ErrorMsg = "Platform not defined for this geography";
                    res.ErrorData = err;
                }
            }
            catch (Exception xe)
            {
                res.ErrorData = new ErrorData();
                res.ErrorData.ErrorMsg = xe.Message;
                res.ErrorData.ErrorCode = 488;
            }

            return res;
        }
    }
}
