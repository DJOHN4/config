﻿using Intact.Specialty.Sup.Framework;
using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.DataInterfaces;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Intact.Specialty.Common.Api.Data
{
    public class BusinessUnitData : IBusinessUnitData
    {
        IDataController dataController = null;

        public BusinessUnitData()
        {
        }

        public void MapMyData()
        {
           //Implement all data mapping to this API contract.
        }
    }
}
