﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Impl.RE
{
    public class InRuleController : RuleEngineController, IRuleEngineController
    {
        public string Check()
        {
            return "This is from InRule";
        }
    }
}
