﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Impl.RE
{
    public abstract class RuleEngineController
    {
    }
}
