﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Impl.DB
{
    public class SQLDbController : DataController, IDataController
    {
        public SQLDbController(string con) : base(con)
        {
        }
        public object OpenDataStore()
        {
            throw new NotImplementedException();
        }
    }
}
