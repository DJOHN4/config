﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Impl.DB
{
    public abstract class DataController
    {
        private string __connString { get; set; } //we can take this from config file
        public DataController(string conn) { this.__connString = conn; }

        public void OpenConnection()
        {

        }
    }
}
