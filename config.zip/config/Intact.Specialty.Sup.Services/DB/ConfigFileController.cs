﻿using Intact.Specialty.Sup.Interfaces;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Intact.Specialty.Sup.Impl.DB
{
    public class ConfigFileController : DataController, IDataController
    {
        public ConfigFileController(string con) : base(con)
        {
        }

        //public List<string> GetMyBusinessUnits()
        //{
        //    JObject configObj = OpenConfigFile();
        //    //Iterate to get the Business Units
        //    return new List<string>();
        //}

        public object OpenDataStore()
        {
            //Read JSON directly from a file
            JObject o2;
            using (StreamReader file = File.OpenText(@"config.json"))
            using (JsonTextReader reader = new JsonTextReader(file))
            {
                o2 = (JObject)JToken.ReadFrom(reader);
            }
            return o2;
        }
    }
}