﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Impl.PA
{
    public class JarusController: PolicyAdminController, IPolicyAdminController
    {
        public string Check()
        {
            return "This is from Jarus";
        }
    }
}
