﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Impl.PA
{
    public abstract class PolicyAdminController
    {
    }
}
