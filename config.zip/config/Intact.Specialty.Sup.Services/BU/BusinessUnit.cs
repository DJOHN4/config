﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Services
{
    public abstract class BusinessUnit
    {
        private string __myGEo { get; set; }
        public BusinessUnit(string geo) { this.__myGEo = geo; }

        public List<string> AppendPrefixtoBU(List<string> buList) //This is common code for all Regions
        {
            string bu = string.Empty;
            for (int i = 0; i < buList.Count; i++)
            {
                buList[i] = this.__myGEo + "-" + buList[i];
            }
            return buList;
        }

        public string GetMyGeography()
        {
            return __myGEo;
        }
    }
}
