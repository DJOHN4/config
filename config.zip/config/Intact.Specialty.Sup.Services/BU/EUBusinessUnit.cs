﻿using Intact.Specialty.Sup.Interfaces;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Services
{
    public class EUBusinessUnit : BusinessUnit, IBusinessUnit
    {
        IDataController dataController = null;
  
        public EUBusinessUnit(string _geo, IDataController dController) : base(_geo) { dataController = dController; }


        public List<string> GetAllMyBusinessUnits()
        {
            List<string> buList = new List<string>();

            JObject configObj = (JObject)dataController.OpenDataStore(); //TODO -- make common for SQl, NoSQl and Files

            //Do the query from this data controller Object
            JToken tokenParent = configObj["Config"];
            foreach (JToken tok in tokenParent)
            {
                if (tok["Region"].ToString() == base.GetMyGeography())
                {
                    JToken tokenChild = tok["Elements"];
                    foreach (JToken tokChild in tokenChild["BusinessUnits"])
                    {
                        buList.Add(tokChild.ToString());
                    }
                }
            }

            return buList;
        }

        public string GetGeography()
        {
            return base.GetMyGeography();
        }

        public List<string> AppendPrefixtoMyBU()
        {
            return base.AppendPrefixtoBU(GetAllMyBusinessUnits());
        }

        public string SpecificCode()
        {
            return "EU uses signle visa";
        }

        public string ThisOnlyForUS() //One problem with the design
        {
            //No need to implement this outside US
            return string.Empty;
        }
    }
}
