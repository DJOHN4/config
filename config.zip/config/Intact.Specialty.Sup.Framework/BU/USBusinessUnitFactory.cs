﻿
using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.DataInterfaces;
using Intact.Specialty.Sup.Services;
using System;

namespace Intact.Specialty.Sup.Framework
{
    public class USBusinessUnitFactory : BusinessUnitFactory
    {
        public override IBusinessUnit GetBusinessUnits(string platform, IDataController dataController)
        {
            IBusinessUnit usBU = new USBusinessUnit(platform, dataController);
            return usBU;
        }
    }
}

/*

    public class USBusinessUnitFactory : BusinessUnitFactory
    {
        public string GetBusinessUnits()
        {
            
        }
    }

    public class EUBusinessUnitFactory : BusinessUnitFactory
    {
        public string GetBusinessUnits()
        {
            return "Movies";
        }
    }

    public class UKBusinessUnitFactory : BusinessUnitFactory
    {
        public string GetBusinessUnits()
        {
            return "Entertainment";
        }
    }

    public class CanadaBusinessUnitFactory : BusinessUnitFactory
    {
        public string GetBusinessUnits()
        {
            return "Inland Marine";
        }
    }
*/