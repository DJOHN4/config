﻿using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.DataInterfaces;
using Intact.Specialty.Sup.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework
{
    public class EUBusinessUnitFactory : BusinessUnitFactory
    {
        public override IBusinessUnit GetBusinessUnits(string platform, IDataController dataController)
        {
            IBusinessUnit usBU = new EUBusinessUnit(platform, dataController);
            return usBU;
        }
    }
}
