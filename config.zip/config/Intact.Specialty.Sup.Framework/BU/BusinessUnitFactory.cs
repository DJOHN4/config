﻿using Intact.Specialty.Sup.Interfaces;
using Intact.Specialty.Sup.Interfaces.DataInterfaces;
using System;

namespace Intact.Specialty.Sup.Framework
{
    public abstract class BusinessUnitFactory
    {
        public static BusinessUnitFactory GetBusinessUnitFactory(string platformGeo)
        {
            switch (platformGeo)
            {
                case "US":
                    return new USBusinessUnitFactory();
                case "EU":
                    return new EUBusinessUnitFactory();
                case "UK":
                    return new UKBusinessUnitFactory();
                default:
                    return null;
            }
        }
        public abstract IBusinessUnit GetBusinessUnits(string platformGeo, IDataController dataController);
    }
}
