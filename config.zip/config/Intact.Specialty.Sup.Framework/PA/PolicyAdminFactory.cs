﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework.RE
{
    public abstract class PolicyAdminFactory
    {
        public static PolicyAdminFactory GetRuleEngineFactory(string toggleContext)
        {
            switch (toggleContext)
            {
                case "Jarus":
                    return new JarusFactory();
                default:
                    return null;
            }
        }
        public abstract IPolicyAdminController GetPolicyAdminController();
    }
}
