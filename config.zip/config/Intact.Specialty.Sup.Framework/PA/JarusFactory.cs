﻿using Intact.Specialty.Sup.Impl.PA;
using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework.RE
{
    public class JarusFactory : PolicyAdminFactory
    {
        public override IPolicyAdminController GetPolicyAdminController()
        {
            IPolicyAdminController jarusPA = new JarusController();
            return jarusPA;
        }
    }
}
