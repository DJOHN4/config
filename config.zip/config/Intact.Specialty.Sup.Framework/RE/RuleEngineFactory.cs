﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework.RE
{
    public abstract class RuleEngineFactory
    {
        public static RuleEngineFactory GetRuleEngineFactory(string toggleContext)
        {
            switch (toggleContext)
            {
                case "InRule":
                    return new InRuleFactory();
                default:
                    return null;
            }
        }
        public abstract IRuleEngineController GetRuleEngineController();
    }
}
