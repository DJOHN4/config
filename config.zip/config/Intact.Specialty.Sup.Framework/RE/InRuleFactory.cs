﻿using Intact.Specialty.Sup.Impl.RE;
using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework.RE
{
    public class InRuleFactory : RuleEngineFactory
    {
        public override IRuleEngineController GetRuleEngineController()
        {
            IRuleEngineController reController = new InRuleController();
            return reController;
        }
    }
}
