﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework
{
    public class SqlDbFactory : DataControllerFactory
    {
        public override IDataController GetDataController()
        {
            throw new Exception("SQL DB connection failed");
        }
    }
}
