﻿using Intact.Specialty.Sup.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework
{
    public abstract class DataControllerFactory
    {
        public static DataControllerFactory GetDataControllerFactory(string toggleContext)
        {
            switch (toggleContext)
            {
                case "File":
                    return new FileFactory();
                case "MongoDB":
                    return new NoSqlDbFactory();
                case "SQLServer":
                    return new SqlDbFactory();
                default:
                    return null;
            }
        }
        public abstract IDataController GetDataController();
    }
}
