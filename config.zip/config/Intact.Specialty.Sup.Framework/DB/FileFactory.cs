﻿using Intact.Specialty.Sup.Impl.DB;
using Intact.Specialty.Sup.Interfaces;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Text;

namespace Intact.Specialty.Sup.Framework
{
    public class FileFactory : DataControllerFactory
    {
        public override IDataController GetDataController()
        {
            IDataController usBU = new ConfigFileController(string.Empty);
            return usBU;
        }
    }
}
